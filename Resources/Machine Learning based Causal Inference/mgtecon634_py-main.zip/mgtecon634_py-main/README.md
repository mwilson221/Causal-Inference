# mgtecon634_python
This tutorial will introduce key concepts in machine learning-based causal inference. This tutorial is used by professor Susan Athey in the MGTECON 634 at Stanford. Scripts were translated into Python.
